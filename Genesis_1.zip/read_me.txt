Cortex Genesis Save
Generation: 10